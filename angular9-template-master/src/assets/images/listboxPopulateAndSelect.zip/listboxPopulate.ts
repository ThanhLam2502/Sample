﻿/// <reference path="../../scripts/typings/angularjs/angular.d.ts" />
/// <reference path="../../scripts/typings/devextreme/dx.devextreme.d.ts" />

//http://js.devexpress.com/Documentation/ApiReference/UI_Widgets/dxList/Configuration/?version=15_1#itemTemplate

module aModule {

	class MyCtrl {

		myScope: any;
		constructor($scope: any) {
			var self: MyCtrl = this;
			this.myScope = $scope;
			this.myScope.onClick = function () {
				var items = self.myScope.mySelectedItems;
				var result = "items selected: ";
				for (var index = 0; index < items.length; index++)
					result += items[index].name + ", ";
				alert(result);
			}

			this.myScope.mySelectedItems = [];
			this.myScope.dataSource = new DevExpress.data.DataSource({
				store: [],
			});
			this.myScope.listOptions1 = {
				height: "40%",
				bindingOptions: {
					dataSource: "dataSource",
					selectedItems: "mySelectedItems",
				},
				editEnabled: true,
				editConfig: {
					selectionEnabled: true,
					selectionType: 'item',
				},
				selectionMode: 'single',
			};
			this.myScope.itemTemplateName = "item2";
			this.myScope.listOptions2 = {
				height: "40%",
				bindingOptions: {
					dataSource: "dataSource",
					selectedItems: "mySelectedItems",
					itemTemplate: "itemTemplateName",
				},
				editEnabled: true,
				editConfig: {
					selectionEnabled: true,
					selectionType: 'item',
				},
				selectionMode: 'multiple',
			};

			this.myScope.dataSource.store().insert({ name: "a1" });
			this.myScope.dataSource.store().insert({ name: "b2" });
			console.log("set1");

			setTimeout(function () {
				//http://js.devexpress.com/Documentation/Guide/Data_Visualization/Charts/Data_Binding/?version=14_2&approach=Knockout#Data_Visualization_Charts_Data_Binding_Update_Data_Using_AngularJS
				//$scope.$apply(function () {

					self.myScope.dataSource.store().insert({ name: "c3" });
					self.myScope.dataSource.store().insert({ name: "d4" });
					self.myScope.dataSource.load().done(function (items) {
						self.myScope.mySelectedItems = [self.myScope.dataSource.items()[1]];
					});
					console.log("set2");
				//});
				//alert("time is up");
			}, 2000);
        }
    }

    MyCtrl.$inject = ['$scope'];
	angular.module("myApp", ['dx']).controller("myCtrl", MyCtrl);
};

 