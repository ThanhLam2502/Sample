import {Component} from '@angular/core';

@Component({
  selector: 'app-layout-single-card',
  templateUrl: './single-card.component.html',
  styleUrls: ['./single-card.component.scss']
})
export class SingleCardLayoutComponent {
  constructor() {
  }
}
