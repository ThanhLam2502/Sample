import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'app-router-outlet',
    template: `<router-outlet></router-outlet>`
})
export class RouterOutletComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {
    }

}
