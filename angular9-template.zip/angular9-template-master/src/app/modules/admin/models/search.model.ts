export interface ISearchDataInterface {
    keyword: string;
}

export class SearchFormDataModel implements ISearchDataInterface {
    keyword: string;
}
