import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-md-auth',
  template: `<router-outlet></router-outlet>`
})
export class AuthComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }
}
