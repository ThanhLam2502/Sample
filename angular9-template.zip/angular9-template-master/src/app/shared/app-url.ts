export enum AppUrl {
  Login = 'login',
  Forbidden = 'forbidden'
}
